import tkinter as tk
from gui import AddressBookGUI

def main():
    """Main function to run the application"""
    root = tk.Tk()
    app = AddressBookGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()