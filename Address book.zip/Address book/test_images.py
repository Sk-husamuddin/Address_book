"""
Test script to check if your images are loading correctly
Run this in your address_book folder
"""

import os
from PIL import Image

def test_images():
    image_folder = "images"
    
    # Check if images folder exists
    if not os.path.exists(image_folder):
        print("❌ ERROR: 'images' folder not found!")
        print("📁 Please create an 'images' folder in your address_book directory")
        return False
    
    print("✅ 'images' folder found!\n")
    
    # List of required images
    required_images = [
        'save.png',
        'update.png', 
        'clear.png',
        'delete.png',
        'view.png',
        'message.png',
        'call.png',
        'video.png',
        'mail.png',
        'edit.png',
        'logo.png'
    ]
    
    print("Checking for image files:\n")
    found_count = 0
    
    for img_name in required_images:
        img_path = os.path.join(image_folder, img_name)
        if os.path.exists(img_path):
            try:
                img = Image.open(img_path)
                print(f"✅ {img_name:15} - Found! Size: {img.size}")
                found_count += 1
            except Exception as e:
                print(f"⚠️  {img_name:15} - Found but can't open: {e}")
        else:
            print(f"❌ {img_name:15} - NOT FOUND")
    
    print(f"\n📊 Summary: {found_count}/{len(required_images)} images found")
    
    if found_count == 0:
        print("\n⚠️  NO IMAGES FOUND!")
        print("The app will use emoji icons as fallback.")
    elif found_count < len(required_images):
        print("\n⚠️  Some images are missing.")
        print("Missing images will use emoji fallback.")
    else:
        print("\n🎉 All images found! Your custom icons should work!")
    
    return found_count > 0

if __name__ == "__main__":
    print("=" * 50)
    print("IMAGE LOADER TEST")
    print("=" * 50 + "\n")
    
    try:
        from PIL import Image
        print("✅ Pillow (PIL) is installed\n")
    except ImportError:
        print("❌ Pillow (PIL) is NOT installed!")
        print("📦 Install it with: pip install Pillow\n")
        exit()
    
    test_images()
    
    print("\n" + "=" * 50)
    input("\nPress Enter to close...")