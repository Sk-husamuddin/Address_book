import tkinter as tk
from tkinter import ttk, messagebox
import re
from database import DatabaseManager
from PIL import Image, ImageTk
import os

class AddressBookGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("📇 Digital Address Book")
        
        # Get screen dimensions
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # Set window size (80% of screen)
        window_width = int(screen_width * 0.8)
        window_height = int(screen_height * 0.85)
        
        # Center the window
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.root.configure(bg="#F2F2F7")
        self.root.minsize(1000, 700)
        
        # Initialize database
        self.db = DatabaseManager()
        
        # Variable to track if we're editing
        self.editing_contact_id = None
        
        # Dark mode state
        self.is_dark_mode = False
        
        # Define color themes
        self.themes = {
            'light': {
                'bg': '#F5E6D3',             # Soft beige/cream (lightest)
                'panel_bg': '#FFF9E3',       # Very light cream (almost white)
                'header_bg': '#FFD93D',      # Bright yellow header
                'text': '#4F200D',           # Dark brown text (readable)
                'secondary_text': '#FF8C42', # Orange accents
                'input_bg': '#FFF4E0',       # Light cream inputs
                'separator': '#FFA500',      # Orange separators
                'table_even': '#FFF9E3',     # Light cream even rows
                'table_odd': '#FFFBF0',      # Almost white odd rows
                'section_bg': '#FFF4D6',     # Soft yellow sections
            },
            'dark': {
                'bg': '#0B0B0B',             # Very dark background (almost black)
                'panel_bg': '#1A1A1A',       # Dark panels
                'header_bg': '#00FFFF',      # Neon cyan header
                'text': '#9DF1DF',           # Neon green text (Matrix style!)
                'secondary_text': '#FF00FF', # Neon pink/magenta
                'input_bg': '#1A1A1A',       # Dark input backgrounds
                'separator': '#00FFFF',      # Neon cyan separators
                'table_even': '#0D0D0D',     # Very dark even rows
                'table_odd': '#1A1A1A',      # Slightly lighter odd rows
                'section_bg': '#1A1A1A',     # Dark sections
            }
        }
        
        # Current theme
        self.current_theme = self.themes['light']
        
        # Load images
        self.load_images()
        
        # Create UI
        self.create_widgets()
        self.apply_theme()
        self.load_contacts()
        
    
    def load_images(self):
        """Load all images for buttons"""
        self.images = {}
        image_folder = "images"
        
        # Define image files and their keys
        image_files = {
            'save': 'save.png',
            'update': 'update.png',
            'clear': 'clear.png',
            'delete': 'delete.png',
            'view': 'view.png',
            'search': 'search.png',
            'message': 'message.png',
            'call': 'call.png',
            'video': 'video.png',
            'mail': 'mail.png',
            'edit': 'edit.png',
            'logo': 'logo.png'
        }
        
        for key, filename in image_files.items():
            try:
                img_path = os.path.join(image_folder, filename)
                if os.path.exists(img_path):
                    # Load and resize image
                    img = Image.open(img_path)
                    
                    # Different sizes for different buttons
                    if key in ['save', 'update', 'clear']:
                        img = img.resize((20, 20), Image.Resampling.LANCZOS)
                    elif key in ['message', 'call', 'video', 'mail', 'edit']:
                        img = img.resize((65, 65), Image.Resampling.LANCZOS)
                    elif key == 'logo':
                        img = img.resize((32, 32), Image.Resampling.LANCZOS)
                    else:
                        img = img.resize((24, 24), Image.Resampling.LANCZOS)
                    
                    self.images[key] = ImageTk.PhotoImage(img)
                else:
                    # Fallback to None if image doesn't exist
                    self.images[key] = None
            except Exception as e:
                print(f"Error loading image {filename}: {e}")
                self.images[key] = None
    
    def create_rounded_button(self, parent, text, bg_color, command, width=12, image_key=None):
        """Create a rounded button with optional image"""
        if image_key and self.images.get(image_key):
            # Button with image and text
            btn = tk.Button(parent, text=f"  {text}", font=("Arial", 11, "bold"),
                           bg=bg_color, fg="white", bd=0, cursor="hand2",
                           command=command, padx=10, pady=10,
                           relief=tk.FLAT, activebackground=bg_color,
                           image=self.images[image_key], compound=tk.LEFT)
        else:
            # Button without image (fallback with emoji)
            emoji_map = {'save': '💾', 'update': '✏️', 'clear': '🔄'}
            emoji = emoji_map.get(image_key, '')
            btn = tk.Button(parent, text=f"{emoji} {text}", font=("Arial", 11, "bold"),
                           bg=bg_color, fg="white", bd=0, cursor="hand2",
                           command=command, padx=15, pady=10, width=width,
                           relief=tk.FLAT, activebackground=bg_color)
        return btn
    
    def create_input_field(self, parent, label_text, is_text=False, height=1):
        """Create a styled input field with label"""
        theme = self.current_theme
        
        container = tk.Frame(parent, bg=theme['panel_bg'])
        container.pack(fill=tk.X, padx=20, pady=8)
        
        label = tk.Label(container, text=label_text, font=("Arial", 11, "bold"), 
                        bg=theme['panel_bg'], fg=theme['secondary_text'], anchor="w")
        label.pack(fill=tk.X, pady=(0, 8))
        
        field_bg = tk.Frame(container, bg=theme['input_bg'], bd=0)
        field_bg.pack(fill=tk.X)
        
        if is_text:
            field = tk.Text(field_bg, font=("Arial", 12), height=height,
                        relief=tk.FLAT, bg=theme['input_bg'], bd=0, padx=8, pady=6,
                        wrap=tk.WORD, fg=theme['text'],
                        insertbackground='#FF00FF' if self.is_dark_mode else '#FF8C42')
        else:
            field = tk.Entry(field_bg, font=("Arial", 12),
                        relief=tk.FLAT, bg=theme['input_bg'], bd=0,
                        fg=theme['text'])
            field.config(insertbackground='#FF00FF' if self.is_dark_mode else '#FF8C42')
            field.pack(fill=tk.X, padx=8, pady=6)
        
        if is_text:
            field.pack(fill=tk.BOTH, expand=True)
        
        return field 
    def create_widgets(self):
        """Create all GUI elements with iOS style"""
        
        # Title Bar
        title_frame = tk.Frame(self.root, bg="#007AFF", height=65)
        title_frame.pack(fill=tk.X)
        title_frame.pack_propagate(False)
        
        # Logo if available
        if self.images.get('logo'):
            logo_label = tk.Label(title_frame, image=self.images['logo'], bg="#007AFF")
            logo_label.pack(side=tk.LEFT, padx=(30, 10), pady=15)
        
        title_label = tk.Label(title_frame, text="Digital Address Book", 
                              font=("Arial", 24, "bold"), bg="#007AFF", fg="white")
        title_label.pack(side=tk.LEFT, padx=(0 if self.images.get('logo') else 30, 30), pady=15)
        
        # Dark mode toggle button
        self.theme_toggle_btn = tk.Button(title_frame, text="🌙", font=("Arial", 20),
                                         bg="#007AFF", fg="white", bd=0, cursor="hand2",
                                         command=self.toggle_theme, relief=tk.FLAT,
                                         activebackground="#0051D5", width=2)
        self.theme_toggle_btn.pack(side=tk.RIGHT, padx=30)
        
        # Main container
        main_container = tk.Frame(self.root, bg="#F2F2F7")
        main_container.pack(fill=tk.BOTH, expand=True, padx=25, pady=20)
        
        # LEFT PANEL - Input Form (40% width)
        left_panel = tk.Frame(main_container, bg="#ffffff", relief=tk.FLAT, bd=0)
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 8))
        left_panel.config(highlightbackground="#E5E5EA", highlightthickness=1)
        
        # Make left panel take 40% of width
        left_panel.config(width=400)
        
        # Form Title
        form_title_frame = tk.Frame(left_panel, bg="#F9F9FB", height=65)
        form_title_frame.pack(fill=tk.X)
        form_title_frame.pack_propagate(False)
        
        form_title = tk.Label(form_title_frame, text="Contact Information", 
                             font=("Arial", 18, "bold"), bg="#F9F9FB", fg="#000000")
        form_title.pack(pady=18, padx=25, anchor="w")
        
        # Separator
        tk.Frame(left_panel, bg="#E5E5EA", height=1).pack(fill=tk.X)
        
        # Scrollable form area
        form_canvas = tk.Canvas(left_panel, bg="#ffffff", highlightthickness=0)
        scrollbar_form = ttk.Scrollbar(left_panel, orient="vertical", command=form_canvas.yview)
        scrollable_form = tk.Frame(form_canvas, bg="#ffffff")
        
        scrollable_form.bind(
            "<Configure>",
            lambda e: form_canvas.configure(scrollregion=form_canvas.bbox("all"))
        )
        
        form_canvas.create_window((0, 0), window=scrollable_form, anchor="nw", width=300)
        form_canvas.configure(yscrollcommand=scrollbar_form.set)
        
        # Input Fields
        tk.Frame(scrollable_form, bg="#ffffff", height=15,width=400).pack()
        
        self.name_entry = self.create_input_field(scrollable_form, "Name *")
        self.phone_entry = self.create_input_field(scrollable_form, "Phone Number *")
        self.email_entry = self.create_input_field(scrollable_form, "Email Address *")
        
        # Bind Enter key to save
        self.name_entry.bind('<Return>', lambda e: self.save_or_update())
        self.phone_entry.bind('<Return>', lambda e: self.save_or_update())
        self.email_entry.bind('<Return>', lambda e: self.save_or_update())
        
        # Visual separator
        sep_frame = tk.Frame(scrollable_form, bg="#ffffff", height=30)
        sep_frame.pack(fill=tk.X)
        tk.Frame(sep_frame, bg="#E5E5EA", height=1).pack(fill=tk.X, padx=15, pady=15)
        
        self.address_entry = self.create_input_field(scrollable_form, "Address (Optional)", True, 3)
        self.notes_entry = self.create_input_field(scrollable_form, "Notes (Optional)", True, 4)
        
        tk.Frame(scrollable_form, bg="#ffffff", height=20).pack()
        
        form_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_form.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Buttons Frame
        button_frame = tk.Frame(left_panel, bg="#ffffff", height=85)
        button_frame.pack(fill=tk.X, side=tk.BOTTOM, pady=(5, 0))
        button_frame.pack_propagate(False)


        tk.Frame(button_frame, bg="#E5E5EA", height=1).pack(fill=tk.X)
        
        btn_container = tk.Frame(button_frame, bg="#ffffff")
        btn_container.pack(expand=False)
        
        # Save Button
        self.save_btn = self.create_rounded_button(btn_container, "Save", "#34C759", 
                                                   self.save_contact, 10, 'save')
        self.save_btn.pack(side=tk.LEFT, padx=5)
        
        # Update Button
        self.update_btn = self.create_rounded_button(btn_container, "Update", "#007AFF",
                                                     self.update_contact, 10, 'update')
        self.update_btn.pack(side=tk.LEFT, padx=5)
        
        # Clear Button
        clear_btn = self.create_rounded_button(btn_container, "Clear", "#8E8E93",
                                              self.clear_form, 10, 'clear')
        clear_btn.pack(side=tk.LEFT, padx=5)
        
        # RIGHT PANEL - Contact List (60% width)
        right_panel = tk.Frame(main_container, bg="#ffffff", relief=tk.FLAT, bd=0)
        right_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right_panel.config(highlightbackground="#E5E5EA", highlightthickness=1)
        
        # Header
        header_frame = tk.Frame(right_panel, bg="#F9F9FB", height=105)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="All Contacts", font=("Arial", 20, "bold"),
                bg="#F9F9FB", fg="#000000").pack(anchor=tk.W, padx=25, pady=(15, 8))
        
        # Search Frame
        search_container = tk.Frame(header_frame, bg="#F9F9FB")
        search_container.pack(fill=tk.X, padx=25, pady=(0, 15))
        
        search_bg = tk.Frame(search_container, bg="#E5E5EA", bd=0)
        search_bg.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        self.search_entry = tk.Entry(search_bg, font=("Arial", 12), relief=tk.FLAT,
                                     bg="#E5E5EA", fg="#000000", bd=0, 
                                     insertbackground="#007AFF")
        self.search_entry.pack(fill=tk.BOTH, padx=7, pady=5)
        self.search_entry.bind('<KeyRelease>', self.search_contacts)
        self.search_entry.insert(0, "🔍 Search contacts...")
        self.search_entry.bind('<FocusIn>', self.on_search_focus_in)
        self.search_entry.bind('<FocusOut>', self.on_search_focus_out)
        self.search_entry.config(fg="#8E8E93")
        
        # Delete button
        if self.images.get('delete'):
            delete_btn = tk.Button(search_container, image=self.images['delete'],
                                  bg="#FF3B30", fg="white", bd=0, cursor="hand2",
                                  command=self.delete_contact, width=40, height=40,
                                  relief=tk.FLAT, activebackground="#FF3B30")
        else:
            delete_btn = tk.Button(search_container, text="🗑️", font=("Arial", 15),
                                  bg="#FF3B30", fg="white", bd=0, cursor="hand2",
                                  command=self.delete_contact, width=4, padx=10, pady=8,
                                  relief=tk.FLAT, activebackground="#FF3B30")
        delete_btn.pack(side=tk.LEFT, padx=(12, 0))
        
        # View button (iOS style)
        if self.images.get('view'):
            view_btn = tk.Button(search_container, image=self.images['view'],
                                bg="#007AFF", fg="white", bd=0, cursor="hand2",
                                command=self.show_contact_details, width=40, height=40,
                                relief=tk.FLAT, activebackground="#007AFF")
        else:
            view_btn = tk.Button(search_container, text="👁️", font=("Arial", 15),
                                bg="#007AFF", fg="white", bd=0, cursor="hand2",
                                command=self.show_contact_details, width=4, padx=10, pady=8,
                                relief=tk.FLAT, activebackground="#007AFF")
        view_btn.pack(side=tk.LEFT, padx=(8, 0))
        
        # Separator
        tk.Frame(right_panel, bg="#E5E5EA", height=1).pack(fill=tk.X)
        
        # Contact Table
        table_frame = tk.Frame(right_panel, bg="#ffffff")
        table_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Custom Treeview style
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Custom.Treeview",
                       background="#ffffff",
                       foreground="#000000",
                       fieldbackground="#ffffff",
                       borderwidth=0,
                       relief="flat",
                       rowheight=40,
                       font=("Arial", 11))
        style.configure("Custom.Treeview.Heading",
                       background="#F9F9FB",
                       foreground="#8E8E93",
                       borderwidth=1,
                       relief="flat",
                       font=("Arial", 11, "bold"))
        style.map('Custom.Treeview',
                 background=[('selected', '#007AFF')],
                 foreground=[('selected', 'white')])
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 5))
        
        # Treeview
        self.contact_table = ttk.Treeview(table_frame, 
                                         columns=("ID", "Name", "Phone", "Email"),
                                         show="headings", 
                                         yscrollcommand=scrollbar.set,
                                         style="Custom.Treeview",
                                         selectmode="browse")
        scrollbar.config(command=self.contact_table.yview)
        
        # Define columns
        self.contact_table.heading("ID", text="ID")
        self.contact_table.heading("Name", text="NAME")
        self.contact_table.heading("Phone", text="PHONE")
        self.contact_table.heading("Email", text="EMAIL")
        
        # Column widths - responsive
        self.contact_table.column("ID", width=0, stretch=tk.NO)
        self.contact_table.column("Name", minwidth=100, width=180)
        self.contact_table.column("Phone", minwidth=120, width=150)
        self.contact_table.column("Email", minwidth=150, width=200)
        
        self.contact_table.pack(fill=tk.BOTH, expand=True, padx=15, pady=10)
        
        # Bind events
        self.contact_table.bind('<Double-1>', self.on_contact_double_click)
        self.contact_table.bind('<<TreeviewSelect>>', self.on_contact_select)
        self.contact_table.bind('<Button-1>', self.on_single_click)
        
        # Status Bar
        status_frame = tk.Frame(right_panel, bg="#F9F9FB", height=50)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)
        status_frame.pack_propagate(False)
        
        tk.Frame(status_frame, bg="#E5E5EA", height=1).pack(fill=tk.X)
        
        status_container = tk.Frame(status_frame, bg="#F9F9FB")
        status_container.pack(fill=tk.BOTH, expand=True)
        
        self.status_label = tk.Label(status_container, text="Total Contacts: 0", 
                                     font=("Arial", 11), bg="#F9F9FB", fg="#8E8E93")
        self.status_label.pack(side=tk.LEFT, padx=25, pady=12)
        
        tk.Label(status_container, text="Double-click to view", 
                font=("Arial", 10), bg="#F9F9FB", fg="#AEAEB2").pack(side=tk.RIGHT, padx=25)
    
    def on_search_focus_in(self, event):
        """Handle search field focus in"""
        if self.search_entry.get() == "🔍 Search contacts...":
            self.search_entry.delete(0, tk.END)
            self.search_entry.config(fg="#000000")
    
    def on_search_focus_out(self, event):
        """Handle search field focus out"""
        if self.search_entry.get() == "":
            self.search_entry.insert(0, "🔍 Search contacts...")
            self.search_entry.config(fg="#8E8E93")
    
    def on_contact_select(self, event):
        """Handle contact selection"""
        selected = self.contact_table.selection()
        if selected:
            contact_id = self.contact_table.item(selected[0])['values'][0]
            contacts = self.db.get_all_contacts()
            for contact in contacts:
                if contact[0] == contact_id:
                    name = contact[1]
                    self.status_label.config(text=f"Total Contacts: {len(contacts)} | Selected: {name}")
                    break
    
    def validate_email(self, email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def validate_phone(self, phone):
        """Validate phone number"""
        phone_clean = re.sub(r'[^0-9+]', '', phone)
        return len(phone_clean) >= 10
    
    def save_or_update(self):
        """Save or update based on current mode"""
        if self.editing_contact_id is not None:
            self.update_contact()
        else:
            self.save_contact()
    
    def save_contact(self):
        """Save new contact to database"""
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        email = self.email_entry.get().strip()
        address = self.address_entry.get("1.0", tk.END).strip()
        notes = self.notes_entry.get("1.0", tk.END).strip()
        
        if not name or not phone or not email:
            messagebox.showerror("Error", "Please fill all required fields (Name, Phone, Email)",
                               parent=self.root)
            return
        
        if not self.validate_phone(phone):
            messagebox.showerror("Error", "Please enter a valid phone number (at least 10 digits)",
                               parent=self.root)
            return
        
        if not self.validate_email(email):
            messagebox.showerror("Error", "Please enter a valid email address",
                               parent=self.root)
            return
        
        if self.db.add_contact(name, phone, email, address, notes):
            messagebox.showinfo("Success", "✓ Contact added successfully!",
                              parent=self.root)
            self.clear_form()
            self.load_contacts()
    
    def update_contact(self):
        """Update existing contact"""
        if self.editing_contact_id is None:
            return
        
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        email = self.email_entry.get().strip()
        address = self.address_entry.get("1.0", tk.END).strip()
        notes = self.notes_entry.get("1.0", tk.END).strip()
        
        if not name or not phone or not email:
            messagebox.showerror("Error", "Please fill all required fields",
                               parent=self.root)
            return
        
        if not self.validate_phone(phone):
            messagebox.showerror("Error", "Please enter a valid phone number",
                               parent=self.root)
            return
        
        if not self.validate_email(email):
            messagebox.showerror("Error", "Please enter a valid email address",
                               parent=self.root)
            return
        
        if self.db.update_contact(self.editing_contact_id, name, phone, email, address, notes):
            messagebox.showinfo("Success", "✓ Contact updated successfully!",
                              parent=self.root)
            self.clear_form()
            self.load_contacts()
    
    def delete_contact(self):
        """Delete selected contact"""
        selected = self.contact_table.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a contact to delete",
                                 parent=self.root)
            return
        
        result = messagebox.askyesno("Confirm Delete", 
                                    "Are you sure you want to delete this contact?",
                                    parent=self.root)
        if result:
            contact_id = self.contact_table.item(selected[0])['values'][0]
            if self.db.delete_contact(contact_id):
                messagebox.showinfo("Success", "✓ Contact deleted successfully!",
                                  parent=self.root)
                self.clear_form()
                self.load_contacts()
    
    def load_contacts(self):
        """Load all contacts into the table"""
        for item in self.contact_table.get_children():
            self.contact_table.delete(item)
        
        contacts = self.db.get_all_contacts()
        
        theme = self.current_theme
        
        for i, contact in enumerate(contacts):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.contact_table.insert('', tk.END, values=contact[:4], tags=(tag,))
        
        # Apply theme colors to rows
        self.contact_table.tag_configure('evenrow', background=theme['table_even'],
                                         foreground=theme['text'])
        self.contact_table.tag_configure('oddrow', background=theme['table_odd'],
                                         foreground=theme['text'])
        
        self.status_label.config(text=f"Total Contacts: {len(contacts)}")
    
    def search_contacts(self, event=None):
        """Search contacts in real-time"""
        search_term = self.search_entry.get().strip()
        
        if search_term == "🔍 Search contacts..." or not search_term:
            self.load_contacts()
            return
        
        for item in self.contact_table.get_children():
            self.contact_table.delete(item)
        
        contacts = self.db.search_contacts(search_term)
        
        theme = self.current_theme
        
        for i, contact in enumerate(contacts):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.contact_table.insert('', tk.END, values=contact[:4], tags=(tag,))
        
        # Apply theme colors to rows
        self.contact_table.tag_configure('evenrow', background=theme['table_even'], 
                                         foreground=theme['text'])
        self.contact_table.tag_configure('oddrow', background=theme['table_odd'],
                                         foreground=theme['text'])
        
        self.status_label.config(text=f"Total Contacts: {len(contacts)}")
    
    def on_contact_double_click(self, event):
        selected = self.contact_table.selection()
        if not selected:
            return
    
        contact_id = self.contact_table.item(selected[0])['values'][0]
        contacts = self.db.get_all_contacts()
    
        for contact in contacts:
            if contact[0] == contact_id:
            # Open the iOS-style contact details popup
                self.create_ios_popup(contact)
                break

    
    def clear_form(self):
        """Clear all input fields"""
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)
        self.address_entry.delete("1.0", tk.END)
        self.notes_entry.delete("1.0", tk.END)
        
        # Reset button to Save mode
        if self.images.get('save'):
            self.save_btn.config(text="  Save", bg="#34C759", command=self.save_contact,image=self.images['save'])
        else:
            self.save_btn.config(text="💾 Save", bg="#34C759", command=self.save_contact)
        self.editing_contact_id = None
        
        contacts = self.db.get_all_contacts()
        self.status_label.config(text=f"Total Contacts: {len(contacts)}")
    
    def toggle_theme(self):
        """Toggle between light and dark mode"""
        self.is_dark_mode = not self.is_dark_mode
        self.current_theme = self.themes['dark'] if self.is_dark_mode else self.themes['light']
        
        # Update toggle button
        self.theme_toggle_btn.config(text="☀️" if self.is_dark_mode else "🌙")
        
        # Apply theme
        self.apply_theme()
    
    def apply_theme(self):
        """Apply current theme to all widgets"""
        theme = self.current_theme
        
        # Root window
        self.root.configure(bg=theme['bg'])
        
        # Get all frames and widgets
        def update_widget_colors(widget):
            widget_type = widget.winfo_class()
            
            # Skip buttons with specific colors
            if widget_type == 'Button':
                # Don't change button colors (keep their action colors)
                pass
            elif widget_type == 'Frame':
                current_bg = str(widget.cget('bg'))
                # Update frame backgrounds based on their type
                if current_bg in ['#ffffff', '#1C1C1E', '#FFFAF0', '#111111', '#1A1A1A', '#FFF9E3']:
                    widget.config(bg=theme['panel_bg'])
                elif current_bg in ['#F2F2F7', '#000000', '#FFF8E7', '#0B0B0B', '#FFF5E6', '#F5E6D3']:
                    widget.config(bg=theme['bg'])
                elif current_bg in ['#F9F9FB', '#2C2C2E', '#FFE57F', '#111111', '#FFE4E1', '#FFF4D6']:
                    widget.config(bg=theme['section_bg'])
                elif current_bg in ['#E5E5EA', '#38383A', '#FFB74D', '#00FFFF', '#FFB6C1', '#FFA500']:
                    widget.config(bg=theme['separator'])
            elif widget_type == 'Label':
                current_bg = str(widget.cget('bg'))
                current_fg = str(widget.cget('fg'))
                
                # Update label colors
                if current_bg in ['#ffffff', '#1C1C1E', '#FFFAF0', '#111111', '#1A1A1A', '#FFF9E3']:
                    widget.config(bg=theme['panel_bg'])
                elif current_bg in ['#F2F2F7', '#000000', '#FFF8E7', '#0B0B0B', '#FFF5E6', '#F5E6D3']:
                    widget.config(bg=theme['bg'])
                elif current_bg in ['#F9F9FB', '#2C2C2E', '#FFE57F', '#111111', '#FFE4E1', '#FFF4D6']:
                    widget.config(bg=theme['section_bg'])
                
                # Update text colors
                try:
                    if current_fg in ['#000000', '#FFFFFF', '#333333', '#00FF00', '#2D3436', '#4F200D', '#9DF1DF'] and 'title' not in str(widget):
                        widget.config(fg=theme['text'])
                    elif current_fg in ['#8E8E93', '#FF8C42', '#FF00FF', '#39FF14', '#FF8A5B', '#ff8c42']:
                        widget.config(fg=theme['secondary_text'])
                except:
                    pass
            elif widget_type == 'Entry':
                current_bg = str(widget.cget('bg'))
                if current_bg in ['#E5E5EA', '#2C2C2E', '#F2F2F7', '#FFF3E0', '#1A1A1A', '#FFF0F5', '#FFF4E0']:
                    widget.config(bg=theme['input_bg'], fg=theme['text'],
                                insertbackground='#FF00FF' if self.is_dark_mode else '#FF8C42')
            elif widget_type == 'Text':
                widget.config(bg=theme['input_bg'], fg=theme['text'],
                            insertbackground='#FF00FF' if self.is_dark_mode else '#FF8C42')
            elif widget_type == 'Canvas':
                widget.config(bg=theme['bg'] if str(widget.cget('bg')) in ['#F2F2F7', '#000000'] 
                            else theme['panel_bg'])
            
            # Recursively update children
            for child in widget.winfo_children():
                update_widget_colors(child)
        
        # Update all widgets
        update_widget_colors(self.root)

        # Update title bar colors specifically
        if self.is_dark_mode:
            title_bg = '#00FFFF'  # Neon cyan
        else:
            title_bg = '#FFD93D'  # Bright yellow
        
        # Find and update title frame (if it exists)
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Frame):
                try:
                    if widget.cget('height') == 65:  # Title frame
                        widget.config(bg=title_bg)
                        for child in widget.winfo_children():
                            if isinstance(child, (tk.Label, tk.Button)):
                                child.config(bg=title_bg)
                except:
                    pass               

        # Update Treeview style
        style = ttk.Style()
        style.configure("Custom.Treeview",
                       background=theme['panel_bg'],
                       foreground=theme['text'],
                       fieldbackground=theme['panel_bg'])
        style.configure("Custom.Treeview.Heading",
                       background=theme['section_bg'],
                       foreground=theme['secondary_text'])
        
        # Fix selection colors for dark mode
        if self.is_dark_mode:
            # Neon selection colors for dark mode
            select_bg = '#FDFFC2'  
            select_fg = '#000000'  
        else:
            # Autumn orange selection for light mode
            select_bg = '#FFA500'  # Bright orange
            select_fg = '#4F200D'  # Dark brown text
            
        style.map('Custom.Treeview',
                 background=[('selected', select_bg)],
                 foreground=[('selected', select_fg)])
        
        # Update alternating row colors with proper text color
        self.contact_table.tag_configure('evenrow', background=theme['table_even'], 
                                         foreground=theme['text'])
        self.contact_table.tag_configure('oddrow', background=theme['table_odd'],
                                         foreground=theme['text'])
        
        # Refresh the table to apply new colors
        self.load_contacts()
    
    def on_single_click(self, event):
        """Handle single click on contact"""
        region = self.contact_table.identify("region", event.x, event.y)
        if region == "cell":
            # Small delay to distinguish from double-click
            self.root.after(300, self.check_single_click)
    
    def check_single_click(self):
        """Check if it was a single click (not followed by double-click)"""
        # This will be overridden if double-click happens
        pass
    
    def show_contact_details(self):
        """Show iOS-style contact details popup"""
        selected = self.contact_table.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a contact to view",
                                 parent=self.root)
            return
        
        contact_id = self.contact_table.item(selected[0])['values'][0]
        contacts = self.db.get_all_contacts()
        
        for contact in contacts:
            if contact[0] == contact_id:
                self.create_ios_popup(contact)
                break
    
    def create_ios_popup(self, contact):
        """Create beautiful iOS-style contact details popup"""
        try:
            theme = self.current_theme
            
            # Create main popup window (simpler approach)
            popup = tk.Toplevel(self.root)
            popup.title("Contact Details")
            
            # Center the popup
            popup_width = 500
            popup_height = 650
            
            # Update to get actual window position
            self.root.update_idletasks()
            
            # Safe positioning
            try:
                x = self.root.winfo_x() + (self.root.winfo_width() - popup_width) // 2
                y = self.root.winfo_y() + (self.root.winfo_height() - popup_height) // 2
            except:
                # Fallback to screen center
                x = (self.root.winfo_screenwidth() - popup_width) // 2
                y = (self.root.winfo_screenheight() - popup_height) // 2
            
            popup.geometry(f"{popup_width}x{popup_height}+{x}+{y}")
            popup.configure(bg=theme['bg'])
            popup.resizable(False, False)
            
            # Make it modal
            popup.transient(self.root)
            popup.grab_set()
            
            # Bind Escape key to close
            popup.bind('<Escape>', lambda e: popup.destroy())
        except Exception as e:
            messagebox.showerror("Error", f"Could not create popup: {str(e)}", parent=self.root)
            return
        
        # Header with gradient effect
        if self.is_dark_mode:
            header_bg = '#00FFFF'  # Neon cyan for dark mode
        else:
            header_bg = '#FFD93D'  # Bright yellow for light mode
            
        header_frame = tk.Frame(popup, bg=header_bg, height=160)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        # Close button
        close_btn = tk.Button(header_frame, text="✕", font=("Arial", 16, "bold"),
                             bg=header_bg, fg="white", bd=0, cursor="hand2",
                             command=popup.destroy, relief=tk.FLAT,
                             width=3, height=1, activebackground="#0051D5")
        close_btn.place(x=450, y=10)
        
        # Profile circle with initials (NO BACKGROUND CIRCLES)
        try:
            initials = "".join([word[0].upper() for word in contact[1].split()[:2]])
        except:
            initials = contact[1][:2].upper() if len(contact[1]) >= 2 else contact[1][0].upper()

        canvas = tk.Canvas(header_frame, width=110, height=110, bg=header_bg, 
                        highlightthickness=0)
        canvas.place(x=195, y=35)

        # Draw initials only - NO CIRCLES!
        canvas.create_text(55, 55, text=initials, font=("Arial", 60, "bold"), 
                        fill="white")
                
                # Contact name
        name_label = tk.Label(popup, text=contact[1], font=("Arial", 22, "bold"),
                                    bg=theme['bg'], fg=theme['text'])
        name_label.pack(pady=(10, 8))
        
        # Action buttons row
        action_frame = tk.Frame(popup, bg=theme['bg'])
        action_frame.pack(pady=12)
        
        def create_action_btn(parent, emoji, label, color, cmd=None, img_key=None):
            btn_frame = tk.Frame(parent, bg=theme['bg'])
            btn_frame.pack(side=tk.LEFT, padx=6)
            
            # Circle button with image or emoji
            if img_key and self.images.get(img_key):
                btn = tk.Button(btn_frame, image=self.images[img_key],
                              bg=color, fg="white", width=50, height=50,
                              bd=0, cursor="hand2", relief=tk.FLAT)
            else:
                btn = tk.Button(btn_frame, text=emoji, font=("Arial", 18),
                              bg=color, fg="white", width=3, height=1,
                              bd=0, cursor="hand2", relief=tk.FLAT)
            if cmd:
                btn.config(command=cmd)
            btn.pack()
            
            # Label
            tk.Label(btn_frame, text=label, font=("Arial", 9), 
                    bg=theme['bg'], fg=theme['secondary_text']).pack(pady=(3, 0))
            
            return btn_frame
        
        import webbrowser
        
        def handle_message_choice():
                """Ask user to choose between WhatsApp or Telegram for messaging."""
                choice_win = tk.Toplevel(popup)
                choice_win.title("Select App")
                choice_win.geometry("300x160")
                choice_win.configure(bg=theme['bg'])
                choice_win.transient(popup)
                choice_win.grab_set()

                x = popup.winfo_x() + (popup.winfo_width() - 300) // 2
                y = popup.winfo_y() + (popup.winfo_height() - 160) // 2
                choice_win.geometry(f"300x160+{x}+{y}")

                tk.Label(choice_win, text="Message using:", font=("Arial", 14, "bold"),
                        bg=theme['bg'], fg=theme['text']).pack(pady=(20, 10))

                btn_frame = tk.Frame(choice_win, bg=theme['bg'])
                btn_frame.pack(pady=10)

                def open_whatsapp():
                    webbrowser.open(f"https://wa.me/{contact[2]}")
                    choice_win.destroy()

                def open_telegram():
                    webbrowser.open(f"https://t.me/+{contact[2]}")
                    choice_win.destroy()

                tk.Button(btn_frame, text="WhatsApp", font=("Arial", 11, "bold"),
                        bg="#25D366", fg="white", width=12, bd=0,
                        relief=tk.FLAT, cursor="hand2", command=open_whatsapp).pack(side=tk.LEFT, padx=10)

                tk.Button(btn_frame, text="Telegram", font=("Arial", 11, "bold"),
                        bg="#0088CC", fg="white", width=12, bd=0,
                        relief=tk.FLAT, cursor="hand2", command=open_telegram).pack(side=tk.LEFT, padx=10)
       
        

        def handle_call_choice():
            """Show a popup asking whether to call via WhatsApp or Telegram."""
            choice_win = tk.Toplevel(popup)
            choice_win.title("Select App")
            choice_win.geometry("300x160")
            choice_win.configure(bg=theme['bg'])
            choice_win.transient(popup)
            choice_win.grab_set()

            # Center the popup
            x = popup.winfo_x() + (popup.winfo_width() - 300) // 2
            y = popup.winfo_y() + (popup.winfo_height() - 160) // 2
            choice_win.geometry(f"300x160+{x}+{y}")

            # Question label
            tk.Label(
                choice_win,
                text="Call using:",
                font=("Arial", 14, "bold"),
                bg=theme['bg'],
                fg=theme['text']
            ).pack(pady=(20, 10))

            btn_frame = tk.Frame(choice_win, bg=theme['bg'])
            btn_frame.pack(pady=10)

            def open_whatsapp():
                webbrowser.open(f"https://wa.me/{contact[2]}")
                choice_win.destroy()

            def open_telegram():
                webbrowser.open(f"https://t.me/+{contact[2]}")
                choice_win.destroy()

            # WhatsApp button
            tk.Button(
                btn_frame, text="WhatsApp", font=("Arial", 11, "bold"),
                bg="#25D366", fg="white", width=12, bd=0, relief=tk.FLAT,
                cursor="hand2", command=open_whatsapp
            ).pack(side=tk.LEFT, padx=10)

            # Telegram button
            tk.Button(
                btn_frame, text="Telegram", font=("Arial", 11, "bold"),
                bg="#0088CC", fg="white", width=12, bd=0, relief=tk.FLAT,
                cursor="hand2", command=open_telegram
            ).pack(side=tk.LEFT, padx=10)

        create_action_btn(
            action_frame, "📞", "Call", "#34C759",
            handle_call_choice, 'call'
        )



        def handle_video_choice():
            """Ask user to choose between WhatsApp or Telegram for video calling."""
            choice_win = tk.Toplevel(popup)
            choice_win.title("Select App")
            choice_win.geometry("300x160")
            choice_win.configure(bg=theme['bg'])
            choice_win.transient(popup)
            choice_win.grab_set()

            x = popup.winfo_x() + (popup.winfo_width() - 300) // 2
            y = popup.winfo_y() + (popup.winfo_height() - 160) // 2
            choice_win.geometry(f"300x160+{x}+{y}")

            tk.Label(choice_win, text="Video call using:", font=("Arial", 14, "bold"),
                    bg=theme['bg'], fg=theme['text']).pack(pady=(20, 10))

            btn_frame = tk.Frame(choice_win, bg=theme['bg'])
            btn_frame.pack(pady=10)

            def open_whatsapp():
                webbrowser.open(f"https://wa.me/{contact[2]}?video=true")
                choice_win.destroy()

            def open_telegram():
                webbrowser.open(f"https://t.me/+{contact[2]}")
                choice_win.destroy()

            tk.Button(btn_frame, text="WhatsApp", font=("Arial", 11, "bold"),
                    bg="#25D366", fg="white", width=12, bd=0,
                    relief=tk.FLAT, cursor="hand2", command=open_whatsapp).pack(side=tk.LEFT, padx=10)

            tk.Button(btn_frame, text="Telegram", font=("Arial", 11, "bold"),
                    bg="#0088CC", fg="white", width=12, bd=0,
                    relief=tk.FLAT, cursor="hand2", command=open_telegram).pack(side=tk.LEFT, padx=10)
        

        create_action_btn(action_frame, "💬", "Message", "#007AFF", handle_message_choice, 'message')
        create_action_btn(action_frame, "📹", "Video", "#007AFF", handle_video_choice, 'video')
        
        create_action_btn(action_frame, "✉️", "mail", "#007AFF",
                         lambda: webbrowser.open(f"mailto:{contact[3]}"), 'mail')
        create_action_btn(action_frame, "✏️", "edit", "#8E8E93",
                         lambda: [popup.destroy(), 
                                 self.edit_contact_from_popup(contact[0])], 'edit')
        # Separator
        tk.Frame(popup, bg=theme['separator'], height=1).pack(fill=tk.X, padx=20, pady=10)
        
        # Scrollable details section
        canvas_detail = tk.Canvas(popup, bg=theme['bg'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(popup, orient="vertical", command=canvas_detail.yview)
        details_frame = tk.Frame(canvas_detail, bg=theme['bg'])
        
        details_frame.bind(
            "<Configure>",
            lambda e: canvas_detail.configure(scrollregion=canvas_detail.bbox("all"))
        )
        
        canvas_detail.create_window((0, 0), window=details_frame, anchor="nw", width=480)
        canvas_detail.configure(yscrollcommand=scrollbar.set)
        
        canvas_detail.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=20)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        def create_info_card(parent, label, value, is_link=False):
            card_bg = theme['input_bg']
            card = tk.Frame(parent, bg=card_bg, bd=0)
            card.pack(fill=tk.X, pady=5)
            
            tk.Label(card, text=label, font=("Arial", 10), bg=card_bg,
                    fg=theme['secondary_text'], anchor="w").pack(fill=tk.X, padx=15, pady=(10, 2))
            
            if is_link:
                value_label = tk.Label(card, text=value, font=("Arial", 14),
                                      bg=card_bg, fg="#007AFF", anchor="w",
                                      cursor="hand2")
                value_label.pack(fill=tk.X, padx=15, pady=(0, 10))
            else:
                value_label = tk.Label(card, text=value, font=("Arial", 14),
                                      bg=card_bg, fg=theme['text'], anchor="w")
                value_label.pack(fill=tk.X, padx=15, pady=(0, 10))
        
        # Phone card
        create_info_card(details_frame, "mobile", contact[2])
        
        # Email card
        create_info_card(details_frame, "email", contact[3], is_link=True)
        
        # Address card (if exists)
        if contact[4] and contact[4].strip():
            card_bg = theme['input_bg']
            card = tk.Frame(details_frame, bg=card_bg, bd=0)
            card.pack(fill=tk.X, pady=5)
            
            tk.Label(card, text="address", font=("Arial", 10), bg=card_bg,
                    fg=theme['secondary_text'], anchor="w").pack(fill=tk.X, padx=15, pady=(10, 2))
            
            # Split address into lines if too long
            address_lines = contact[4].split('\n')
            for line in address_lines[:3]:  # Max 3 lines
                if line.strip():
                    tk.Label(card, text=line.strip(), font=("Arial", 13),
                            bg=card_bg, fg=theme['text'], anchor="w",
                            wraplength=450).pack(fill=tk.X, padx=15)
            
            tk.Frame(card, bg=card_bg, height=10).pack()
        
        # Notes card (if exists)
        if contact[5] and contact[5].strip():
            card_bg = theme['input_bg']
            card = tk.Frame(details_frame, bg=card_bg, bd=0)
            card.pack(fill=tk.X, pady=5)
            
            tk.Label(card, text="notes", font=("Arial", 10), bg=card_bg,
                    fg=theme['secondary_text'], anchor="w").pack(fill=tk.X, padx=15, pady=(10, 2))
            
            tk.Label(card, text=contact[5], font=("Arial", 13), bg=card_bg,
                    fg=theme['text'], anchor="w", wraplength=420,
                    justify=tk.LEFT).pack(fill=tk.X, padx=15, pady=(0, 10))
        
        # Bottom space
        tk.Frame(details_frame, bg=theme['bg'], height=20).pack()
        
        # Focus on popup
        popup.focus_set()
    
    def edit_contact_from_popup(self, contact_id):
        """Edit contact after closing popup"""
        contacts = self.db.get_all_contacts()
        for contact in contacts:
            if contact[0] == contact_id:
                self.editing_contact_id = contact_id
                
                self.name_entry.delete(0, tk.END)
                self.name_entry.insert(0, contact[1])
                
                self.phone_entry.delete(0, tk.END)
                self.phone_entry.insert(0, contact[2])
                
                self.email_entry.delete(0, tk.END)
                self.email_entry.insert(0, contact[3])
                
                self.address_entry.delete("1.0", tk.END)
                self.address_entry.insert("1.0", contact[4] if contact[4] else "")
                
                self.notes_entry.delete("1.0", tk.END)
                self.notes_entry.insert("1.0", contact[5] if contact[5] else "")

                if self.images.get('update'):
                    self.save_btn.config(text="  Update", bg="#007AFF", command=self.update_contact,image=self.images['update'])
                else:
                    self.save_btn.config(text="✏️ Update", bg="#007AFF", command=self.update_contact)
                self.editing_contact_id = contact_id
                
