def handle_message_choice():
                """Ask user to choose between WhatsApp or Telegram for messaging."""
                choice_win = tk.Toplevel(popup)
                choice_win.title("Select App")
                choice_win.geometry("300x160")
                choice_win.configure(bg=theme['bg'])
                choice_win.transient(popup)
                choice_win.grab_set()

                x = popup.winfo_x() + (popup.winfo_width() - 300) // 2
                y = popup.winfo_y() + (popup.winfo_height() - 160) // 2
                choice_win.geometry(f"300x160+{x}+{y}")

                tk.Label(choice_win, text="Message using:", font=("Arial", 14, "bold"),
                        bg=theme['bg'], fg=theme['text']).pack(pady=(20, 10))

                btn_frame = tk.Frame(choice_win, bg=theme['bg'])
                btn_frame.pack(pady=10)

                def open_whatsapp():
                    webbrowser.open(f"https://wa.me/{contact[2]}")
                    choice_win.destroy()

                def open_telegram():
                    webbrowser.open(f"https://t.me/+{contact[2]}")
                    choice_win.destroy()

                tk.Button(btn_frame, text="WhatsApp", font=("Arial", 11, "bold"),
                        bg="#25D366", fg="white", width=12, bd=0,
                        relief=tk.FLAT, cursor="hand2", command=open_whatsapp).pack(side=tk.LEFT, padx=10)

                tk.Button(btn_frame, text="Telegram", font=("Arial", 11, "bold"),
                        bg="#0088CC", fg="white", width=12, bd=0,
                        relief=tk.FLAT, cursor="hand2", command=open_telegram).pack(side=tk.LEFT, padx=10)
       
        

        def handle_call_choice():
            """Show a popup asking whether to call via WhatsApp or Telegram."""
            choice_win = tk.Toplevel(popup)
            choice_win.title("Select App")
            choice_win.geometry("300x160")
            choice_win.configure(bg=theme['bg'])
            choice_win.transient(popup)
            choice_win.grab_set()

            # Center the popup
            x = popup.winfo_x() + (popup.winfo_width() - 300) // 2
            y = popup.winfo_y() + (popup.winfo_height() - 160) // 2
            choice_win.geometry(f"300x160+{x}+{y}")

            # Question label
            tk.Label(
                choice_win,
                text="Call using:",
                font=("Arial", 14, "bold"),
                bg=theme['bg'],
                fg=theme['text']
            ).pack(pady=(20, 10))

            btn_frame = tk.Frame(choice_win, bg=theme['bg'])
            btn_frame.pack(pady=10)

            def open_whatsapp():
                webbrowser.open(f"https://wa.me/{contact[2]}")
                choice_win.destroy()

            def open_telegram():
                webbrowser.open(f"https://t.me/+{contact[2]}")
                choice_win.destroy()

            # WhatsApp button
            tk.Button(
                btn_frame, text="WhatsApp", font=("Arial", 11, "bold"),
                bg="#25D366", fg="white", width=12, bd=0, relief=tk.FLAT,
                cursor="hand2", command=open_whatsapp
            ).pack(side=tk.LEFT, padx=10)

            # Telegram button
            tk.Button(
                btn_frame, text="Telegram", font=("Arial", 11, "bold"),
                bg="#0088CC", fg="white", width=12, bd=0, relief=tk.FLAT,
                cursor="hand2", command=open_telegram
            ).pack(side=tk.LEFT, padx=10)

        create_action_btn(
            action_frame, "📞", "Call", "#34C759",
            handle_call_choice, 'call'
        )



        def handle_video_choice():
            """Ask user to choose between WhatsApp or Telegram for video calling."""
            choice_win = tk.Toplevel(popup)
            choice_win.title("Select App")
            choice_win.geometry("300x160")
            choice_win.configure(bg=theme['bg'])
            choice_win.transient(popup)
            choice_win.grab_set()

            x = popup.winfo_x() + (popup.winfo_width() - 300) // 2
            y = popup.winfo_y() + (popup.winfo_height() - 160) // 2
            choice_win.geometry(f"300x160+{x}+{y}")

            tk.Label(choice_win, text="Video call using:", font=("Arial", 14, "bold"),
                    bg=theme['bg'], fg=theme['text']).pack(pady=(20, 10))

            btn_frame = tk.Frame(choice_win, bg=theme['bg'])
            btn_frame.pack(pady=10)

            def open_whatsapp():
                webbrowser.open(f"https://wa.me/{contact[2]}?video=true")
                choice_win.destroy()

            def open_telegram():
                webbrowser.open(f"https://t.me/+{contact[2]}")
                choice_win.destroy()

            tk.Button(btn_frame, text="WhatsApp", font=("Arial", 11, "bold"),
                    bg="#25D366", fg="white", width=12, bd=0,
                    relief=tk.FLAT, cursor="hand2", command=open_whatsapp).pack(side=tk.LEFT, padx=10)

            tk.Button(btn_frame, text="Telegram", font=("Arial", 11, "bold"),
                    bg="#0088CC", fg="white", width=12, bd=0,
                    relief=tk.FLAT, cursor="hand2", command=open_telegram).pack(side=tk.LEFT, padx=10)
        

        create_action_btn(action_frame, "💬", "Message", "#007AFF", handle_message_choice, 'message')
        create_action_btn(action_frame, "📹", "Video", "#007AFF", handle_video_choice, 'video')
        
        create_action_btn(action_frame, "✉️", "mail", "#007AFF",
                         lambda: webbrowser.open(f"mailto:{contact[3]}"), 'mail')
        create_action_btn(action_frame, "✏️", "edit", "#8E8E93",
                         lambda: [popup.destroy(), 
                                 self.edit_contact_from_popup(contact[0])], 'edit')
        