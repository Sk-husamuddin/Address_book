import sqlite3
from tkinter import messagebox

class DatabaseManager:
    def __init__(self, db_name="contacts.db"):
        """Initialize database connection"""
        self.db_name = db_name
        self.create_table()
    
    def create_connection(self):
        """Create a connection to the SQLite database"""
        try:
            conn = sqlite3.connect(self.db_name)
            return conn
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error connecting to database: {e}")
            return None
    
    def create_table(self):
        """Create contacts table if it doesn't exist"""
        conn = self.create_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS contacts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        phone TEXT NOT NULL UNIQUE,
                        email TEXT NOT NULL,
                        address TEXT,
                        notes TEXT
                    )
                ''')
                conn.commit()
                conn.close()
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Error creating table: {e}")
    
    def add_contact(self, name, phone, email, address="", notes=""):
        """Add a new contact to the database"""
        conn = self.create_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO contacts (name, phone, email, address, notes)
                    VALUES (?, ?, ?, ?, ?)
                ''', (name, phone, email, address, notes))
                conn.commit()
                conn.close()
                return True
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "This phone number already exists!")
                return False
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Error adding contact: {e}")
                return False
    
    def get_all_contacts(self):
        """Retrieve all contacts from database"""
        conn = self.create_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM contacts ORDER BY name')
                contacts = cursor.fetchall()
                conn.close()
                return contacts
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Error retrieving contacts: {e}")
                return []
    
    def update_contact(self, contact_id, name, phone, email, address="", notes=""):
        """Update an existing contact"""
        conn = self.create_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE contacts 
                    SET name=?, phone=?, email=?, address=?, notes=?
                    WHERE id=?
                ''', (name, phone, email, address, notes, contact_id))
                conn.commit()
                conn.close()
                return True
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "This phone number already exists!")
                return False
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Error updating contact: {e}")
                return False
    
    def delete_contact(self, contact_id):
        """Delete a contact from database"""
        conn = self.create_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM contacts WHERE id=?', (contact_id,))
                conn.commit()
                conn.close()
                return True
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Error deleting contact: {e}")
                return False
    
    def search_contacts(self, search_term):
        """Search contacts by name, phone, or email"""
        conn = self.create_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM contacts 
                    WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?
                    ORDER BY name
                ''', (f'%{search_term}%', f'%{search_term}%', f'%{search_term}%'))
                contacts = cursor.fetchall()
                conn.close()
                return contacts
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Error searching contacts: {e}")
                return []